#
#usage: python htmlFG.py ipl_directory pathway_directory pathway_pids.tab
#   $1            ipl_directory contains one IPL matrix per pathway
#   $2            pathway_directory contains one spf file per pathway
#   $3            pathway_pids.tab is a 3 col file with list of pathways in pathway_directory: pid, description, source
#                   Note: pathway names must start with pid_ and end with _pathway.tab
#   $4            contrast file with col_1 sample IDs and col_2 with sample group name
#   $5            sample group name from CONTRAST_FILE to use for contrast
#   $6            sample group name from CONTRAST_FILE to use for contrast

python htmlFG.py $1 $2 $3 $4 $5 $6 index.html
